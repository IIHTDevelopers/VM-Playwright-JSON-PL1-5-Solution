import { Page, Locator, expect } from "@playwright/test";
import path from 'path';
const filePath = path.resolve(__dirname, '../../TestImage.jpg');
const commentText = "this is test comment";
const editPostText = "this is edit post comment";


export default class buzzPage {
  readonly page: Page;
private photoComment: Locator;
  private buzzLink: Locator;
  private sharephoto: Locator;
  private buzzImage: Locator;
  private submitButton: Locator;
  private likeCount: Locator;
  private likeButton: Locator;
  private firstPostFooter: Locator;
  private commentInput : Locator;
  private firstCommentButton: Locator;
  private latestComment: Locator;
  private editToggle : Locator;
  private editButton: Locator;
  private postEdit: Locator;
  private postButton : Locator;
  private verifyCmnt: Locator;
  constructor(page: Page) {
    this.page = page;
    this.buzzLink = page.locator('span.oxd-main-menu-item--name', { hasText: 'Buzz' });
    this.sharephoto = page.locator("//button[normalize-space()='Share Photos']");
    this.buzzImage = page.locator('input.oxd-file-input');
    this.submitButton = page.locator("//button[normalize-space()='Share']");
    this.editToggle= page.locator("(//button[@type='button'])[9]");
    this.editButton = page.locator("//li[@class='orangehrm-buzz-post-header-config-item'][2]");
    this.firstPostFooter = page.locator('div.orangehrm-buzz-post-footer').first();
    this.photoComment= page.locator("//textarea[@placeholder=\"What's on your mind?\"]");


    this.likeCount = this.firstPostFooter.locator('p:has-text("like")');
    this.likeButton = this.firstPostFooter.locator('#heart-svg');
    this.commentInput = this.page.locator('[placeholder="Write your comment..."]');
    this.firstCommentButton = this.page.locator("//div[@class='orangehrm-buzz-post-actions']/button[1]").first();
    this.latestComment = this.page.locator("//div[@class='orangehrm-post-comment-area'] / span[@class='oxd-text oxd-text--span orangehrm-post-comment-text']")
    this.postEdit = this.page.locator("(//textarea[@class='oxd-buzz-post-input'])[2]");
    this.postButton = this.page.locator("//div[@class = 'oxd-form-actions orangehrm-buzz-post-modal-actions']/button")
    this.verifyCmnt = this.page.locator("//div[@class='orangehrm-buzz-post-body']/p"); 
  }



  async SharePhotoPost(): Promise<{commentText: string, commentList: string[]}> {
  await this.buzzLink.click();
  await this.sharephoto.click();

  const commentText = generateCommentWithTimestamp("Nice photo");
  await this.photoComment.nth(1).fill(commentText);
  await this.buzzImage.setInputFiles(filePath);
  await this.submitButton.click();
  await this.page.waitForTimeout(5000);
  await  this.page.reload();
  const commentList = await this.page.locator("//div[@class='orangehrm-buzz-post-body']/p[1]").allTextContents();
  console.log(commentList,commentText);
  return {commentText,commentList};
}



  async likePost(): Promise<{ initialNumber: number, updatedNumber: number }> {
    await this.buzzLink.click();
    const statText = await this.likeCount.textContent();
    const initialNumber = parseInt(statText?.match(/\d+/)?.[0] || '0', 10);
    await this.likeButton.click();
    await this.page.waitForTimeout(2000);
    const updatedStatText = await this.likeCount.textContent();
    const updatedNumber = parseInt(updatedStatText?.match(/\d+/)?.[0] || '0', 10);
    return { initialNumber, updatedNumber };
  }

  async addCommentToPost(): Promise<string> {
    const commentText = generateCommentWithTimestamp("Nice comment");
    if (!commentText) throw new Error("Comment text is null or undefined");

  await this.buzzLink.click();
  await this.page.waitForTimeout(3000);
  await this.firstCommentButton.click();
  

  await this.commentInput.fill(commentText);
  await this.commentInput.press('Enter');
  await this.page.waitForTimeout(2000);
  
  const postedCommentText = await this.latestComment.first().textContent();
  return postedCommentText?.trim() || '';
}


 public async editPost(): Promise<string> {
  if (!editPostText) throw new Error("editPostText is null or undefined");

  await this.buzzLink.click();
  await this.editToggle.click();
  await this.editButton.click();
  await this.postEdit.clear();
  await this.postEdit.fill(editPostText);
  await this.postButton.click();
  await this.page.waitForTimeout(2000);

  const postedCommentText = await this.verifyCmnt.first().textContent();
  return postedCommentText?.trim() || '';
}

}

//------------helper functions----------------
function generateCommentWithTimestamp(comment: string): string {
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  const ss = String(now.getSeconds()).padStart(2, '0');
  return `${comment} ${hh}--${mm}--${ss}`;
}