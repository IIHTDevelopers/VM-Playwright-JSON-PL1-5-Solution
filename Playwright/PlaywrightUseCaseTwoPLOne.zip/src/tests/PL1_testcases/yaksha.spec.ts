import {  test } from "playwright/test";
import { Page, Locator, expect } from "@playwright/test";
import { LoginPage } from "../../pages/LoginPage";
import  AdminPage  from "src/pages/AdminPage";
import  buzzpage from "src/pages/buzzPage";
import MedicalRecordsPage from "src/pages/buzzPage";
import { MyInfoPage } from "src/pages/MyInfoPage";



test.describe("Yaksha", () => {
 let loginPage: LoginPage;
 let myinfoPage : MyInfoPage;
 let adminPage : AdminPage ;
 let buzzPage: buzzpage;
 

  test.beforeEach(async ({ page, baseURL }) => {
    await page.goto("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    loginPage = new LoginPage(page);
    myinfoPage= new MyInfoPage(page); 
    adminPage = new AdminPage(page);
    buzzPage = new buzzpage(page);
    await loginPage.performLogin();
  });

 

  test("TS-1 Verify Image could be Uploaded as profile Pic", async ({ page }) => {
    await myinfoPage.myinfo();
    await expect(page.locator("//p[contains(@class,'toast-message')]")).toContainText("Successfully Updated"); });

  test("TS-2 Verify Admin can edit records ", async ({
    page,
  }) => {
    //await loginPage.performLogin();
    await adminPage.AdminEdit();
    await expect(page.locator("//h6[text()='Edit User']")).toBeVisible();
  });

  test("TS-3 verify admin can sort the record", async ({
    page,
  }) => {
    const trimmedRoles = await adminPage.adminSortUsername();
    const actualTrimmedRolesElements = await page.locator('.oxd-table-body .oxd-table-row >> nth=0').locator('xpath=../../..//div[@role="row"]//div[@role="cell"][2]');
    const roles = await actualTrimmedRolesElements.allTextContents();
    const actualTrimmedRoles = roles.map(role => role.trim());
    await assertSortedList(trimmedRoles);
    await assertSortedList(actualTrimmedRoles);
    console.log("Admin can sort the record successfully");
    
  });

  test("TS-4 Verify new Tab opens on clicking the Upgrade button", async ({
    page,
  }) => {
    const childPageUrl = await adminPage.upgrade();
    await expect(childPageUrl).toContain("https://orangehrm.com/open-source/upgrade-to-advanced");
    await expect(newPageUrl).toBe(childPageUrl);
  });

 test("TS-5 Verify tooltip shows up when hovered over 'Help' button ", async ({
    page,
  }) => {
    const tooltipText = await myinfoPage.helpHover();
    await expect(tooltipText).toBe('Help'); 
  });

  

  test("TS-6 Verify admin Seaarch Functionality", async ({ page }) => {
    const roles = await adminPage.adminSearchVerify();
    for (const role of roles) {
      expect(role.trim()).toBe('Admin');
    }

  });

test.only("TS-7 Verify Image could be uploaded in Buzz post", async ({ page }) => {
  const { commentText, commentList } = await buzzPage.SharePhotoPost();
  await page.waitForTimeout(5000);
  commentList.forEach(text => console.log(text));
  expect(commentList.some(c => c.trim() === commentText.trim())).toBe(true);

  console.log("Image dragged and dropped successfully");
});


  test("TS-8 Verify Like button is Functional ", async ({
    page
  }) => {
    const { initialNumber, updatedNumber } = await buzzPage.likePost();
    await assertLikeCountIncreased(initialNumber, updatedNumber);
  });

 test("TS-9 Verify the Comment could be added to a post", async ({ page }) => {
  const postedComment = await buzzPage.addCommentToPost();
  const cmntList = await page.locator('//div/span[text()=""]').allTextContents();
  console.log(cmntList);

  // ✅ Assert the posted comment exists in the list
  expect(cmntList.some(c => c.trim() === postedComment.trim())).toBe(true);
});


  test("TS-10 Verify Edit Post Functionality	", async ({
    page,
  }) => {
    //await loginPage.performLogin();
    const updatedText = await buzzPage.editPost();
  
  await assertEditedPost(updatedText, editPostText);
  await expect(page.locator("//p[contains(@class,'toast-message')]")).toContainText("Successfully Updated");
   
  });
});

/**
 * ------------------------------------------------------Helper Methods----------------------------------------------------
 */
async function assertSortedList(actualList: string[]) {
  for (let i = 0; i < actualList.length - 1; i++) {
    if (actualList[i].localeCompare(actualList[i + 1]) > 0) {
      throw new Error(
        `List is not sorted at index ${i}: '${actualList[i]}' > '${actualList[i + 1]}'`
      );
    }
  }
}

const editPostText = "this is edit post comment";

const newPageUrl = "https://orangehrm.com/open-source/upgrade-to-advanced";


async function assertLikeCountIncreased(initial: number, updated: number) {
  console.log(`Like count increased from ${initial} to ${updated}`);
  expect(updated).toBe(initial + 1);
}

async function assertCommentIsPosted(actual: string, expected: string) {
  expect(actual).toBe(expected);
}
export function assertEditedPost(actual: string, expected: string) {
  expect(actual).toBe(expected);
}

//-----